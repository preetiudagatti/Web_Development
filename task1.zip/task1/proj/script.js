// GSAP Animations
gsap.to('#hero h1', {
    opacity: 1,
    y: 0,
    duration: 1,
    delay: 0.5,
    ease: 'power4.out',
});

gsap.to('#hero p', {
    opacity: 1,
    y: 0,
    duration: 1,
    delay: 1,
    ease: 'power4.out',
});

gsap.to('.project-card', {
    opacity: 1,
    y: 0,
    duration: 1,
    delay: 1.5,
    stagger: 0.3,
    ease: 'power4.out',
});

// Three.js Setup (3D Background Animation)
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer({ canvas: document.getElementById('three-canvas') });
renderer.setSize(window.innerWidth, window.innerHeight);

const geometry = new THREE.BoxGeometry();
const material = new THREE.MeshBasicMaterial({ color: 0x00ff00 });
const cube = new THREE.Mesh(geometry, material);
scene.add(cube);

camera.position.z = 5;

const animate = function() {
    requestAnimationFrame(animate);
    cube.rotation.x += 0.01;
    cube.rotation.y += 0.01;
    renderer.render(scene, camera);
};

animate();

// Adjust Canvas on Window Resize
window.addEventListener('resize', () => {
    renderer.setSize(window.innerWidth, window.innerHeight);
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
});