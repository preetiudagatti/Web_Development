// backend/config.js
require("dotenv").config();

module.exports = {
  MONGO_URI: process.env.MONGO_URI,
  JWT_SECRET: process.env.JWT_SECRET,
  S3_BUCKET_NAME: process.env.S3_BUCKET_NAME
};
