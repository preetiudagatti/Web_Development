// backend/controllers/courseController.js
const Course = require('../models/Course');
const User = require('../models/User');

// 1. Create a new course
exports.createCourse = async (req, res) => {
  const { title, description, instructor, videoUrl } = req.body;

  try {
    // Ensure the instructor exists (you can use authenticated user ID from req.userId)
    const user = await User.findById(instructor);
    if (!user) {
      return res.status(404).json({ message: 'Instructor not found' });
    }

    // Create a new course
    const newCourse = new Course({
      title,
      description,
      instructor: user._id,
      videoUrl, // URL of the course video
      quizzes: [] // Initially no quizzes
    });

    // Save the course to the database
    await newCourse.save();

    // Add the course to the instructor's courses (optional)
    user.courses.push(newCourse._id);
    await user.save();

    // Respond with the created course
    res.status(201).json(newCourse);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};

// 2. Get all courses
exports.getAllCourses = async (req, res) => {
  try {
    const courses = await Course.find().populate('instructor', 'username email');
    res.json(courses);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};

// 3. Get a single course by its ID
exports.getCourseById = async (req, res) => {
  const { courseId } = req.params;

  try {
    const course = await Course.findById(courseId).populate('instructor', 'username email').populate('quizzes');
    if (!course) {
      return res.status(404).json({ message: 'Course not found' });
    }
    res.json(course);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};
