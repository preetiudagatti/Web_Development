// backend/controllers/quizController.js
const Quiz = require('../models/Quiz');
const Course = require('../models/Course');

// 1. Create a new quiz for a specific course
exports.createQuiz = async (req, res) => {
  const { courseId } = req.params;
  const { title, questions } = req.body;

  try {
    // Check if the course exists
    const course = await Course.findById(courseId);
    if (!course) {
      return res.status(404).json({ message: 'Course not found' });
    }

    // Create a new quiz for the course
    const newQuiz = new Quiz({
      title,
      questions
    });

    // Save the quiz to the database
    await newQuiz.save();

    // Add the quiz to the course
    course.quizzes.push(newQuiz._id);
    await course.save();

    res.status(201).json(newQuiz);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};

// 2. Get all quizzes for a specific course
exports.getQuizzesForCourse = async (req, res) => {
  const { courseId } = req.params;

  try {
    // Fetch course to get quizzes
    const course = await Course.findById(courseId).populate('quizzes');
    if (!course) {
      return res.status(404).json({ message: 'Course not found' });
    }

    res.json(course.quizzes);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};

// 3. Submit quiz answers
exports.submitQuiz = async (req, res) => {
  const { quizId, userAnswers } = req.body;

  try {
    // Find the quiz by its ID
    const quiz = await Quiz.findById(quizId);
    if (!quiz) {
      return res.status(404).json({ message: 'Quiz not found' });
    }

    // Check answers and calculate score
    let score = 0;
    quiz.questions.forEach((question, index) => {
      if (userAnswers[index] === question.correctAnswer) {
        score += 1;
      }
    });

    res.json({ message: 'Quiz submitted successfully', score });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};
