// backend/routes/courseRoutes.js
const express = require("express");
const Course = require("../models/Course");

const router = express.Router();

// Get all courses
router.get("/", async (req, res) => {
  const courses = await Course.find();
  res.json(courses);
});

// Get a single course by ID
router.get("/:id", async (req, res) => {
  const course = await Course.findById(req.params.id).populate("quizzes");
  res.json(course);
});

module.exports = router;

