// backend/controllers/quizController.js
const Quiz = require('../models/Quiz');
const Course = require('../models/Course');

// 1. Get quizzes for a specific course
exports.getQuizzesForCourse = async (req, res) => {
  try {
    const courseId = req.params.courseId;
    
    // Fetch quizzes related to the course
    const course = await Course.findById(courseId).populate('quizzes');
    
    if (!course) {
      return res.status(404).json({ message: 'Course not found' });
    }
    
    return res.json(course.quizzes);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};

// 2. Submit quiz answers
exports.submitQuiz = async (req, res) => {
  try {
    const { userId, quizId, answers } = req.body;

    // Find the quiz by its ID
    const quiz = await Quiz.findById(quizId);

    if (!quiz) {
      return res.status(404).json({ message: 'Quiz not found' });
    }

    // Check if answers are correct and calculate the score
    let score = 0;

    quiz.questions.forEach((question, index) => {
      if (answers[index] === question.correctAnswer) {
        score += 1;
      }
    });

    // Save the result (you can extend this to track individual user progress)
    // You can also save the score to the User model, but here, we're just sending the result
    res.json({ message: 'Quiz submitted successfully', score });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};
