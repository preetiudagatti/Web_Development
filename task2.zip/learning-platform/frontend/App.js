// frontend/src/App.js
import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import CourseList from './components/CourseList';
import CourseDetail from './pages/CourseDetail';
import About from './pages/About';
import NavBar from './components/NavBar'; // You might have a NavBar component for site navigation
import './App.css';

function App() {
  return (
    <Router>
      <div className="App">
        {/* Include the navigation bar */}
        <NavBar />
        
        {/* Define routes for different pages */}
        <Switch>
          {/* Home route */}
          <Route exact path="/" component={Home} />
          
          {/* Login and Registration routes */}
          <Route path="/login" component={Login} />
          <Route path="/register" component={Register} />
          
          {/* Course listing and detail pages */}
          <Route path="/courses" component={CourseList} />
          <Route path="/courses/:courseId" component={CourseDetail} />
          
          {/* About page route */}
          <Route path="/about" component={About} />
        </Switch>
      </div>
    </Router>
  );
}

export default App;
