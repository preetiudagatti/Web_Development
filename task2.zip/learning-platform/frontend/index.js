// frontend/src/index.js
import React from 'react';
import ReactDOM from 'react-dom';
import App from './App'; // Import the root App component
import './index.css'; // Import global styles
import { BrowserRouter as Router } from 'react-router-dom'; // Router for navigation

// Render the App component wrapped in a Router to enable routing
ReactDOM.render(
  <Router>
    <App />
  </Router>,
  document.getElementById('root') // This connects the app to the 'root' element in your HTML
);
