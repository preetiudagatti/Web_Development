// frontend/src/components/CourseDetail.js
import React, { useEffect, useState } from "react";
import axios from "axios";

function CourseDetail({ match }) {
  const [course, setCourse] = useState(null);

  useEffect(() => {
    axios.get(`http://localhost:5000/api/courses/${match.params.id}`)
      .then(response => {
        setCourse(response.data);
      })
      .catch(error => console.error(error));
  }, [match.params.id]);

  return (
    <div>
      {course ? (
        <>
          <h1>{course.title}</h1>
          <p>{course.description}</p>
          <video controls>
            <source src={course.videoUrl} type="video/mp4" />
          </video>
        </>
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );
}

export default CourseDetail;
