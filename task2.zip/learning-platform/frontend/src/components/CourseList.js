// frontend/src/components/CourseList.js
import React, { useEffect, useState } from "react";
import axios from "axios";

function CourseList() {
  const [courses, setCourses] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:5000/api/courses")
      .then(response => {
        setCourses(response.data);
      })
      .catch(error => console.error(error));
  }, []);

  return (
    <div>
      <h1>Courses</h1>
      <ul>
        {courses.map(course => (
          <li key={course._id}>
            <a href={`/courses/${course._id}`}>{course.title}</a>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default CourseList;
