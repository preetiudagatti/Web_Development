import React, { useState, useEffect } from "react";
import { io } from "socket.io-client";
import './styles.css'; // Optional styling file

// Connect to the backend server
const socket = io("http://localhost:4000");

function App() {
    const [content, setContent] = useState("");

    // Fetch the initial document content from the server when the app starts
    useEffect(() => {
        socket.on("document-change", (newContent) => {
            setContent(newContent);
        });

        // Request initial document content from the server
        fetch("http://localhost:4000/document")
            .then((response) => response.json())
            .then((data) => {
                setContent(data.content);
            })
            .catch((err) => console.error("Error fetching document:", err));

        return () => {
            socket.off("document-change");
        };
    }, []);

    const handleChange = (e) => {
        const newContent = e.target.value;
        setContent(newContent);
        socket.emit("document-change", newContent); // Send updates to the server
    };

    return ( < div className = "App" >
        <
        h1 > Real - Time Collaborative Document Editor < /h1> <
        textarea value = { content }
        onChange = { handleChange }
        placeholder = "Start typing..."
        rows = "20"
        cols = "80" /
        >
        <
        /div>
    );
}

export default App;