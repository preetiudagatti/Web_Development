const mongoose = require("mongoose");

// Define the schema for the document
const documentSchema = new mongoose.Schema({
    content: {
        type: String,
        required: true,
    },
});

// Create the model based on the schema
const Document = mongoose.model("Document", documentSchema);

module.exports = Document;